# A basic BinaryTree web With Ajax 
Basic operations with:
- Inserting an element.
- Removing an element.
- Searching for an element.
- Deletion for an element.
- Traversing an element. There are four (mainly three) types of  traversals in a binary tree which will be discussed ahead.