﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ape_arbolBinario
{
    class BTree
    {
        Nodo raiz;

        public BTree()
        {
            raiz = null;
        }

        public void Agregar(Nodo nuevo)
        {
            if (raiz == null)
            {
                raiz = nuevo;
            }
            else
            {
                Agregar(nuevo, raiz);
            }
        }

        private void Agregar(Nodo nuevo, Nodo padre)
        {
            if (nuevo.dato < padre.dato)
            {
                if (padre.izq == null)
                {
                    padre.izq = nuevo;
                }
                else
                {
                    Agregar(nuevo, padre.izq);
                }
            }
            else
            {
                if (padre.der == null)
                {
                    padre.der = nuevo;
                }
                else
                {
                    Agregar(nuevo, padre.der);
                }
            }
        }

        public Nodo Buscar(int numABuscar)
        {
            if (raiz == null)
            {
                return null;
            }
            else if (Convert.ToInt32(raiz.dato) == numABuscar)
            {
                return raiz;
            }
            else
            {
                return Buscar(numABuscar, raiz);
            }
        }

        private Nodo Buscar(int numABuscar, Nodo padre)
        {
            if (padre == null)
            {
                return null;
            }
            if (Convert.ToInt32(padre.dato) == numABuscar)
            {
                return padre;
            }
            else if (numABuscar < Convert.ToInt32(padre.dato))
            {
                if (padre.izq != null)
                {
                    if (Convert.ToInt32(padre.izq.dato) == numABuscar)
                    {
                        return padre.izq;
                    }
                    else
                    {
                        return Buscar(numABuscar, padre.izq);
                    }
                }
            }
            else
            {
                if (padre.der != null)
                {
                    if (Convert.ToInt32(padre.der.dato) == numABuscar)
                    {
                        return padre.der;
                    }
                    else
                    {
                        return Buscar(numABuscar, padre.der);
                    }
                }
            }

            return null;
        }

        public string InOrder()
        {
            if (raiz == null)
            {
                return "";
            }
            else
            {
                return InOrder(raiz);
            }
        }

        private string InOrder(Nodo R)
        {
            string inOrderStr = "";

            if (R.izq != null)
            {
                inOrderStr += InOrder(R.izq);
            }
            inOrderStr += R.ToString() + " ";

            if (R.der != null)
            {
                inOrderStr += InOrder(R.der);
            }
            return inOrderStr;
        }

        public string PreOrder()
        {
            if (raiz == null)
            {
                return "";
            }
            else
            {
                return PreOrder(raiz);
            }
        }

        private string PreOrder(Nodo R)
        {
            string preOrderStr = "";
            preOrderStr += R.ToString() + " ";

            if (R.izq != null)
            {
                preOrderStr += PreOrder(R.izq);
            }

            if (R.der != null)
            {
                preOrderStr += PreOrder(R.der);
            }
            return preOrderStr;
        }

        public string PostOrder()
        {
            if (raiz == null)
            {
                return "";
            }
            else
            {
                return PostOrder(raiz);
            }
        }

        private string PostOrder(Nodo R)
        {
            string postOrderStr = "";

            if (R.izq != null)
            {
                postOrderStr += PostOrder(R.izq);
            }

            if (R.der != null)
            {
                postOrderStr += PostOrder(R.der);
            }
            postOrderStr += R.ToString() + " ";
            return postOrderStr;
        }
    }
}




