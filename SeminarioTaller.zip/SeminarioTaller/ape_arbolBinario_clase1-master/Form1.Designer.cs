﻿namespace ape_arbolBinario
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.txtAgregar = new System.Windows.Forms.TextBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.btnpostOrder = new System.Windows.Forms.Button();
            this.btnpreOrder = new System.Windows.Forms.Button();
            this.btninOrder = new System.Windows.Forms.Button();
            this.txtReporte = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtBuscar
            // 
            this.txtBuscar.Location = new System.Drawing.Point(116, 153);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(100, 20);
            this.txtBuscar.TabIndex = 0;
            // 
            // txtAgregar
            // 
            this.txtAgregar.Location = new System.Drawing.Point(116, 87);
            this.txtAgregar.Name = "txtAgregar";
            this.txtAgregar.Size = new System.Drawing.Size(100, 20);
            this.txtAgregar.TabIndex = 1;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(265, 85);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 2;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(265, 153);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar.TabIndex = 3;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // btnpostOrder
            // 
            this.btnpostOrder.Location = new System.Drawing.Point(22, 351);
            this.btnpostOrder.Name = "btnpostOrder";
            this.btnpostOrder.Size = new System.Drawing.Size(75, 23);
            this.btnpostOrder.TabIndex = 5;
            this.btnpostOrder.Text = "PostOrder";
            this.btnpostOrder.UseVisualStyleBackColor = true;
            this.btnpostOrder.Click += new System.EventHandler(this.btnpostOrder_Click);
            // 
            // btnpreOrder
            // 
            this.btnpreOrder.Location = new System.Drawing.Point(22, 306);
            this.btnpreOrder.Name = "btnpreOrder";
            this.btnpreOrder.Size = new System.Drawing.Size(75, 23);
            this.btnpreOrder.TabIndex = 6;
            this.btnpreOrder.Text = "PreOrder";
            this.btnpreOrder.UseVisualStyleBackColor = true;
            this.btnpreOrder.Click += new System.EventHandler(this.btnpreOrder_Click);
            // 
            // btninOrder
            // 
            this.btninOrder.Location = new System.Drawing.Point(22, 261);
            this.btninOrder.Name = "btninOrder";
            this.btninOrder.Size = new System.Drawing.Size(75, 23);
            this.btninOrder.TabIndex = 7;
            this.btninOrder.Text = "inOrder";
            this.btninOrder.UseVisualStyleBackColor = true;
            this.btninOrder.Click += new System.EventHandler(this.btninOrder_Click);
            // 
            // txtReporte
            // 
            this.txtReporte.Location = new System.Drawing.Point(183, 275);
            this.txtReporte.Multiline = true;
            this.txtReporte.Name = "txtReporte";
            this.txtReporte.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtReporte.Size = new System.Drawing.Size(200, 85);
            this.txtReporte.TabIndex = 8;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(499, 450);
            this.Controls.Add(this.txtReporte);
            this.Controls.Add(this.btninOrder);
            this.Controls.Add(this.btnpreOrder);
            this.Controls.Add(this.btnpostOrder);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.txtAgregar);
            this.Controls.Add(this.txtBuscar);
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Arbol Binario";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.TextBox txtAgregar;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnpostOrder;
        private System.Windows.Forms.Button btnpreOrder;
        private System.Windows.Forms.Button btninOrder;
        private System.Windows.Forms.TextBox txtReporte;
    }
}

