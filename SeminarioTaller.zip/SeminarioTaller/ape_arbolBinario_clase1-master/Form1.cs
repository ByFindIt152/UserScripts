﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ape_arbolBinario
{
    public partial class frmPrincipal : Form
    {

        BTree arbol = new BTree();
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

           





        }

        private void btnpreOrder_Click(object sender, EventArgs e)
        {
            txtReporte.Text = arbol.PreOrder();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if(txtAgregar.Text == "")
            {
                MessageBox.Show("Agregar el numero");
            }
            else
            {
                arbol.Agregar(new Nodo(Convert.ToUInt16(txtAgregar.Text)));
            }
            txtAgregar.Text = "";
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //Buscar el dato ps 

            if(arbol.Buscar(Convert.ToInt16(txtBuscar.Text))== null)
            {
                MessageBox.Show("No existe el dato en el arbol");
            }
            else
            {
                txtReporte.Text = (arbol.Buscar(Convert.ToInt16(txtBuscar.Text)).ToString());
            }
        }

        private void btninOrder_Click(object sender, EventArgs e)
        {
            txtReporte.Text = arbol.InOrder();
        }

        private void btnpostOrder_Click(object sender, EventArgs e)
        {
            txtReporte.Text = arbol.PostOrder();
        }
    }
}
