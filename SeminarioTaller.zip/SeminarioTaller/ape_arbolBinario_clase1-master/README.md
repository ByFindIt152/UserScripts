# ape_arbolBinario_clase1
Like a binary tree ohooo
1er proyecto- SEM - 4TO SEMESTRE
